/*5. Fac¸a um programa que receba do usuario um arquivo texto e um caracter. Mostre na tela ´
quantas vezes aquele caractere ocorre dentro do arquivo.

BRUNA CAROLINA DA SILVA FEYH 
22/08/2023
*/
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

#define MAX 10000

int contador(char str[], int n, char s){
    int i, j=0;
    
    for(i=0; i<n; i++){
        if (str[i] == s) j++;
    }
    
    return j;
}

int lerarq(char *s, char str[]){
    FILE *f;
    f = fopen(s, "r");
    if(f == NULL) return errno;
    
    fscanf(f, "%[^EOF]", str);
 
    fclose(f);
    return 0;
}
int main()
{
    char ch[MAX], c;
    int erro, tam;
    
    scanf("%c", &c);
    
    erro = lerarq("arq.txt", ch);
    if(erro != 0) printf("erro de leitura: %d\n", erro);
    
    tam = strlen(ch);
    
    printf("O carater ocorre %d vezes dentro do arquivo\n", contador(ch, tam, c));
   
    return 0;
}

